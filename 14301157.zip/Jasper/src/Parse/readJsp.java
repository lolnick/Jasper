package Parse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;



public class readJsp {
	//��ȡ��ǰ����Ŀ¼��"\"
	public static final String WEB_ROOT = System.getProperty("user.dir") + File.separator + "WebRoot";
	
	//���ڶ�ȡjsp�ļ�  
    public static void change(String file, String filename) throws IOException  
    {
    	StringBuffer content = new StringBuffer();
    	String[] names = filename.split("\\.");
    	content.append("package JspServlet;" + "\r\n");
    	int p = file.indexOf("%>", file.lastIndexOf("<%@"));
    	p += 2;
    	int p4 = 0;
    	int p5 = 0;
    	int p6 = 0;
    	int p7 = 0;
    	while(true){
    		p4 = file.indexOf("import", p4);
    		if(p4 == -1 || p4 > p){
    			break;
    		} else{
    			p5 = file.indexOf("\"", p4);
    			p6 = file.indexOf("\"", p5+1);
    			p7 = file.indexOf(";", p4);
    			if(p5<p6){
    				String[] datas = file.substring(p5+1, p7).split(",");
    				for(int i=0; i<datas.length; i++){
    					content.append("import " + datas[i] + ";\r\n");
    				}
    			}
    		}
    		p4 = p6+1;
    	}
    	content.append("import javax.servlet.*;" + "\r\n"
    			+ "import java.io.IOException;" + "\r\n"
    			+ "import java.io.PrintWriter;" + "\r\n"
    			+ "public class " 
    			+ names[0] + "_jsp" 
    			+ " implements Servlet {" + "\r\n"
    			+ "public void init(ServletConfig config) throws ServletException {}" + "\r\n"
    			+ "public void service(ServletRequest request, ServletResponse response)" + "\r\n"
    			+ "throws ServletException, IOException {" + "\r\n"
    			+ "PrintWriter out = response.getWriter();\r\n");
    	
    	content.append("out.println(\"");
    	int p2 = 0;
    	int p3 = 0;
    	int j;
    	while(true){
    		p2 = file.indexOf("<%=", p);
    		p3 = file.indexOf("<%", p);
   // 		System.out.println(p);
    		if(p3 == -1){
    			String[] datas = file.substring(p).split("\n");
    			for(int i=0; i<datas.length; i++){
    				String[] datas2 = datas[i].split("\"");
    				for(j=0; j<datas2.length-1; j++){
    					content.append(datas2[j] + "\\\"");
    				}
    				content.append(datas2[j] + "\");\r\nout.println(\"");
    			}
    			content.append("\");");
    			break;
    		} else{
    			String[] datas = file.substring(p,p3).split("\n");
    			for(int i=0; i<datas.length; i++){
    				String[] datas2 = datas[i].split("\"");
    				for(j=0; j<datas2.length-1; j++){
    					content.append(datas2[j] + "\\\"");
    				}
    				content.append(datas2[j] + "\");\r\nout.println(\"");
    			}
    			content.append("\");");
    			p = file.indexOf("%>", p3);
    			//����һ����ǩ��<%ʱ
    			if(p2==-1){
    				System.out.println("1");
    				content.append(file.substring(p3+2, p));
        	    	content.append("out.println(\"");
    			}else if(p3 < p2){
    				System.out.println("2");
        			content.append(file.substring(p3+2, p));
        			p = file.indexOf("%>", p2);
        	    	content.append("out.println(");
        	    	content.append(");out.println("+file.substring(p2+3, p));
        	    	content.append(");\r\nout.println(\"");
        		}else if(p3>p2){
        			System.out.println("3");
        			content.append("out.println("+file.substring(p2+3, p));
        	    	content.append(");\r\nout.println(\"");
        		}	
        		p += 2;
    		}
    	}
    	content.append("}" + "\r\n"
    			+ "public void destroy() {}" + "\r\n"
    			+ "public String getServletInfo() {" + "\r\n"
    			+ "return null;" + "\r\n"
    			+ "}" + "\r\n"
    			+ "public ServletConfig getServletConfig() {" + "\r\n"
    			+ "return null;}}");
    	outToFile(filename, content);
    }
    	
    private static void outToFile(String filename, StringBuffer content) {
    	// TODO �Զ����ɵķ������
    	String[] jspname = filename.split("\\."); 
    	File jsp = new File(System.getProperty("user.dir") + File.separator 
    			+ "src" + File.separator + "JspServlet" + File.separator + jspname[0] + "_jsp.java");
    //	System.out.println(System.getProperty("user.dir") + File.separator 
   // 			+ "src" + File.separator + "JspServlet" + File.separator + jspname[0] + "_jsp.java");
		try {
			FileOutputStream fos = new FileOutputStream(jsp);
            PrintWriter pw = new PrintWriter(fos);
            pw.write(content.toString().toCharArray());
            pw.flush();
            pw.close();
		} catch (FileNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	//���ڶ�ȡjsp�ļ�  
    public static void readFile(String uri) throws IOException  
    {
        FileInputStream fins = null;
        String filecontent = "";
        try  
        {  
            //��·����Ӧ����ҳ  
            File file = new File(WEB_ROOT, uri);  
            StringBuilder sb = new StringBuilder();
            String s ="";
            BufferedReader br = new BufferedReader(new FileReader(file));

            while( (s = br.readLine()) != null) {
            sb.append(s + "\n");
            }

            br.close();
            filecontent = sb.toString();
        }  
        catch (Exception e)  
        {  
            filecontent = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
        }  
        finally  
        {  
        	//�ر�����
            if (fins != null)  
                fins.close();  
        }  
        System.out.println(filecontent);
        change(filecontent, uri);
    }
}
