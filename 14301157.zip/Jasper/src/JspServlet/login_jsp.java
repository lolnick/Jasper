package JspServlet;
import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
public class login_jsp implements Servlet {
public void init(ServletConfig config) throws ServletException {}
public void service(ServletRequest request, ServletResponse response)
throws ServletException, IOException {
PrintWriter out = response.getWriter();
out.println("");
out.println("");
out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
out.println("<html>");
out.println("<head>");
out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=GB18030\">");
out.println("<title>��¼</title>");
out.println("<link type=\"text/css\" href=\"css/login.css\" rel=\"stylesheet\" />");
out.println(" <script src=\"jquery/jquery-1.8.3.js\"></script>");
out.println("</head>");
out.println("");
out.println("<body>");
out.println("<div id=\"container\">");
out.println("	<iframe id=\"header\" src=\"head.jsp\" width=\"980\" height=\"136\" frameborder=\"0\" scrolling=\"no\" marginwidth=\"0px;\"></iframe>");
out.println("    <img src=\"images/pic1.png\">");
out.println("    <hr/>");
out.println("    ");
out.println("    <div id=\"content\">");
out.println("    	<div id=\"box1\">");
out.println("        <form action=\"LoginServlet?method=login\" method=\"post\">");
out.println("        	<table width=\"330\">");
out.println("        		<tr>");
out.println("                	<td width=\"70\" height=\"40\">��¼��:</td>");
out.println("                <td width=\"180\"><input type=\"text\" name=\"userName\" id=\"userName\" /></td>");
out.println("                    <td width=\"60\"></td>");
out.println("                </tr>");
out.println("                <tr>");
out.println("                	<td >��&nbsp;&nbsp;��:</td>");
out.println("                    <td colspan=\"2\"><input type=\"password\" name=\"userPwd\" id=\"userPwd\"/></td>");
out.println("                </tr>");
out.println("                <tr>");
out.println("                	<td></td>");
out.println("                	<td colspan=\"2\"><font color=\"yellow\">${error}</font></td>");
out.println("                </tr>");
out.println("        	</table>");
out.println("            <div id=\"boxlogin\">");
out.println("            <input type=\"image\" src=\"images/login4.png\" id=\"sub\"/>");
out.println("            </div>");
out.println("            </form>");
out.println("            <div id=\"boxregister\">");
out.println("            <a href=\"register.jsp\">����ע��</a>");
out.println("            <a href=\"\">�������룿</a>");
out.println("            </div>        ");
out.println("            </div>");
out.println("    </div>");
out.println("    <iframe id=\"footer\" src=\"foot.html\" width=\"980\" height=\"136\" frameborder=\"0\" scrolling=\"no\" marginwidth=\"0px\"></iframe>");
out.println("</div>");
out.println("</body>");
out.println("</html>");
out.println("");}
public void destroy() {}
public String getServletInfo() {
return null;
}
public ServletConfig getServletConfig() {
return null;}}